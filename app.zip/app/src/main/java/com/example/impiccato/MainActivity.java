package com.example.impiccato;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int turno = 0;
    private String S;
    private String App;
    private int tentativi = 6;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bottone = (Button)findViewById(R.id.btn0);
        Button rigioca = (Button)findViewById(R.id.btn1);



        final Paint paint = new Paint();
        paint.setColor(Color.parseColor("#EB5922"));
        Bitmap bg = Bitmap.createBitmap(480,800, Bitmap.Config.ARGB_8888);
        final Canvas canvas = new Canvas(bg);
        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.draw);
        canvas.drawRect(85, 0, 120, 750, paint);
        canvas.drawRect(120, 0, 250, 80, paint);
        canvas.drawRect(220, 0, 250, 190, paint);

        linearLayout.setBackground(new BitmapDrawable(bg));
        paint.setColor(Color.BLACK);
        bottone.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        EditText input = (EditText)findViewById(R.id.txt0);
                        TextView output = (TextView) findViewById(R.id.txtV0);
                        TextView error = (TextView) findViewById(R.id.wrong);
                        String Print = "";
                        String In;
                        String Controllo="";
                        if(turno == 0){
                            S = input.getText().toString();
                            S = S.replaceAll(" ","");
                            if(S.length() <= 0){
                                output.setText("La stringa è vuota");
                                return;
                            }
                            S = S.toLowerCase();
                            String t = "";
                            for(int i=0; i<S.length(); i++)
                                t+="_ ";
                            output.setText(t);
                            input.setText("");
                            App = "";
                            turno = 1;
                            input.setHint("Inserisci una lettera o più lettere");
                        }




                        else if(turno == 1){
                            boolean s = false;
                            boolean c = false;
                            In = input.getText().toString();
                            In = In.replaceAll(" ","");
                            In = In.toLowerCase();



                            for(int i = 0; i<(S.length() - (In.length()-1)); i++)
                            {
                                if( (S.substring(i, i + In.length())).equals(In) )
                                {
                                    App += In;
                                    s = true;
                                    for(int j = 0; j < S.length(); j++)
                                    {
                                        c = false;
                                        for(int k=0; k < App.length(); k++) {
                                            if (S.charAt(j) == App.charAt(k))
                                            {
                                                Print += S.charAt(j) + " ";
                                                Controllo+=S.charAt(j);
                                                c = true;
                                                break;
                                            }

                                        }
                                        if(!c)
                                           Print+= "_ ";
                                    }

                                    break;
                                }

                            }

                            if(Controllo.equals(S))
                            {
                                output.setText("Hai vinto: "+Print);
                                turno = 3;
                                return;

                            }

                            if(s){
                                output.setText(Print);
                                Print = "";
                            }
                            else
                            {
                                String mom = error.getText().toString();
                                mom += In + " ";
                                error.setText(mom);
                                tentativi--;
                                if(tentativi == 5){
                                    canvas.drawOval(220, 190, 250, 280, paint);
                                    linearLayout.invalidate();
                                }

                                else if(tentativi == 4){
                                    canvas.drawRect(230, 280, 240, 450, paint);
                                    linearLayout.invalidate();
                                }

                                else if(tentativi == 3){
                                    canvas.drawRect(230, 280, 200, 300, paint);
                                    linearLayout.invalidate();
                                }

                                else if(tentativi == 2){
                                    canvas.drawRect(240, 280, 270, 300, paint);
                                    linearLayout.invalidate();
                                }

                                else if (tentativi == 1){
                                    canvas.drawRect(240, 440, 200, 460, paint);
                                    linearLayout.invalidate();
                                }

                                else if (tentativi == 0){
                                    output.setText("HAI PERSO! La soluzione è: "+ S);
                                    canvas.drawRect(240, 440, 270, 460, paint);
                                    linearLayout.invalidate();
                                    turno = 3;
                                    return;
                                }


                            }

                            input.setText("");
                            input.setHint("Inserisci una lettera o più lettere");


                        }

                    }
                });


        rigioca.setOnClickListener(
                new View.OnClickListener(){

                    public void onClick(View v)
                    {

                        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                        paint.setColor(Color.parseColor("#EB5922"));
                        canvas.drawRect(85, 0, 120, 750, paint);
                        canvas.drawRect(120, 0, 250, 80, paint);
                        canvas.drawRect(220, 0, 250, 190, paint);
                        linearLayout.invalidate();
                        paint.setColor(Color.BLACK);
                        EditText input = (EditText)findViewById(R.id.txt0);
                        TextView output = (TextView) findViewById(R.id.txtV0);
                        TextView error = (TextView) findViewById(R.id.wrong);
                        S = "";
                        App = "";
                        turno = 0;
                        tentativi = 6;
                        input.setText("");
                        input.setHint("Inserisci una parola da indovinare");
                        output.setText("");
                        error.setText("Tentativi errati: ");


                    }

                }
        );
    }
}
